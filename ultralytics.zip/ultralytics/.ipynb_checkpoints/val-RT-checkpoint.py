import sys
sys.path.append("/root/ultralytics-main")
import warnings
warnings.filterwarnings('ignore')

from ultralytics import RTDETR 

# Load your model and train
#model = RTDETR('./rtdetr-l.pt')  
#model.train(data="data.yaml", epochs=200, verbose=True, seed=0, amp=False, batch=8)  

# Validate your model
#metrics = model.val(data="data.yaml", split='test')  # Pass the data argument here

if __name__ == '__main__':
    model = RTDETR('/root/ultralytics-main/ultralytics/runs-MCRT/train-RTDETR/exp-RTDETR/weights/best.pt')
    # model.load('') # loading pretrain weights
    model.val(data='/root/ultralytics-main/ultralytics/cfg/datasets/MC-ship.yaml',
                split='test',
                batch=1,
                imgsz=640,
                epochs=200,
                workers=0,
                device='0',
                # resume='', # last.pt path
                project='runs-MCRT/test-RTDETR',
                name='exp-RTDETR',
                )
