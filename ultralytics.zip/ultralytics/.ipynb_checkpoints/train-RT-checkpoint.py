import sys
sys.path.append("/root/ultralytics-main")
import warnings
warnings.filterwarnings('ignore')
from ultralytics import RTDETR

import warnings
warnings.filterwarnings('ignore')
from ultralytics import RTDETR

if __name__ == '__main__':
    model = RTDETR('/root/ultralytics-main/ultralytics/cfg/models/rt-detr/rtdetr-l.yaml')
    # model.load('') # loading pretrain weights
    model.train(data='/root/ultralytics-main/ultralytics/cfg/datasets/MC-ship.yaml',
                cache=False,
                imgsz=640,
                epochs=200,
                batch=8,
                workers=8,
                device='0',
                # resume='', # last.pt path
                project='runs-MCRT/train-RTDETR',
                name='exp-RTDETR',
                )
