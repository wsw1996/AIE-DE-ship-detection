# DatasetShips > 2022-08-19 2:18pm
https://universe.roboflow.com/visocomputacional/datasetships

Provided by a Roboflow user
License: CC BY 4.0

